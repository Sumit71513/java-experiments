package java10;

import java.util.Random;

class NumberGenerator extends Thread {
    public static int num;

    public void run() {
        Random r = new Random();
        try {
            while (true) {
                num = r.nextInt(100) + 1;  
                System.out.println("\nGenerated Number: " + num);
                Thread.sleep(1000);       
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}

class EvenThread extends Thread {
    public void run() {
        try {
            while (true) {
                int n = NumberGenerator.num;
                if (n % 2 == 0) {
                    System.out.println("Even Thread → Square of " + n + " = " + (n * n));
                }
                Thread.sleep(500);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}

class OddThread extends Thread {
    public void run() {
        try {
            while (true) {
                int n = NumberGenerator.num;
                if (n % 2 != 0) {
                    System.out.println("Odd Thread → Cube of " + n + " = " + (n * n * n));
                }
                Thread.sleep(500);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}

public class thread {

    public static void main(String[] args) {

        NumberGenerator g = new NumberGenerator();
        EvenThread e = new EvenThread();
        OddThread o = new OddThread();

        g.start();
        e.start();
        o.start();
    }
}

