package java9;

public class abstractclass {

    abstract class Shape {
        int a, b;

        abstract void printArea();
    }
    class Rectangle extends Shape {
        Rectangle(int length, int breadth) {
            a = length;
            b = breadth;
        }

        void printArea() {
            System.out.println("Area of Rectangle = " + (a * b));
        }
    }
    class Triangle extends Shape {
        Triangle(int base, int height) {
            a = base;
            b = height;
        }

        void printArea() {
            System.out.println("Area of Triangle = " + (0.5 * a * b));
        }
    }

    class Circle extends Shape {
        Circle(int radius) {
            a = radius;
        }

        void printArea() {
            double area = 3.14159 * a * a;
            System.out.println("Area of Circle = " + area);
        }
    }
    public static void main(String[] args) {

        abstractclass obj = new abstractclass();

        Rectangle r = obj.new Rectangle(10, 5);
        Triangle t = obj.new Triangle(8, 6);
        Circle c = obj.new Circle(7);

        r.printArea();
        t.printArea();
        c.printArea();
    }
}
